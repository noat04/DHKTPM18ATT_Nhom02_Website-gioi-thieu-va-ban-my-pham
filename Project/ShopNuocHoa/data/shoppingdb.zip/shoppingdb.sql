-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.8.4-MariaDB - MariaDB Server
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for shoppingdb
CREATE DATABASE IF NOT EXISTS `shoppingdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;
USE `shoppingdb`;

-- Dumping structure for table shoppingdb.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `country` varchar(100) DEFAULT NULL,
  `imgURL` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKt8o6pivur7nn124jehx7cygw5` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.categories: ~12 rows (approximately)
REPLACE INTO `categories` (`id`, `name`, `country`, `imgURL`) VALUES
	(1, 'Chanel', 'Pháp', 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765121832/shopnuochoa_products/macpfwtyfgd81ojofutf.png'),
	(2, 'Dior', 'Pháp', '	https://i.pinimg.com/1200x/73/9c/18/739c182ecf9a3e7a749690b337cde4b2.jpg'),
	(3, 'Gucci', 'Ý', '	https://thumbs.dreamstime.com/b/gucci-logo-editori…-icons-set-social-media-flat-banner-208332316.jpg'),
	(4, 'Tom Ford', 'Mỹ', 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765121874/shopnuochoa_products/aw4oim877dcov5ocbyp7.png'),
	(5, 'Creed', 'Pháp', 'https://i.pinimg.com/736x/64/5c/90/645c9068c4113d7fdc46ad615eeffc3b.jpg'),
	(7, 'Versace', 'Ý', 'https://images.seeklogo.com/logo-png/14/1/versace-medusa-logo-png_seeklogo-148376.png'),
	(8, 'Yves Saint Laurent', 'Pháp', '	https://images.seeklogo.com/logo-png/28/1/yves-saint-laurent-logo-png_seeklogo-288938.png'),
	(9, 'Giorgio Armani', 'Ý', 'https://images.seeklogo.com/logo-png/39/1/giorgio-armani-logo-png_seeklogo-393860.png'),
	(10, 'Jo Malone', 'Anh', '	https://vipyidiancom.oss-cn-beijing.aliyuncs.com/vipyidian.com/article/0232022090848454.jpg'),
	(11, 'Le Labo', 'Mỹ', 'https://images.seeklogo.com/logo-png/31/1/le-labo-logo-png_seeklogo-316974.png'),
	(12, 'Morra', 'Việt Nam', 'https://interbra.vn/public/DATA/2022/4-2022-46928.jpg'),
	(13, 'ViinRiic', 'Việt Nam', '	https://viinriic.com/wp-content/uploads/2019/06/logo-Mendittorosa-VR-300x300.jpg');

-- Dumping structure for table shoppingdb.comments
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6uv0qku8gsu6x1r2jkrtqwjtn` (`product_id`),
  KEY `fk_comment_customer` (`customer_id`),
  CONSTRAINT `FK6uv0qku8gsu6x1r2jkrtqwjtn` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_comment_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.comments: ~3 rows (approximately)
REPLACE INTO `comments` (`id`, `text`, `product_id`, `rating`, `customer_id`, `created_at`) VALUES
	(17, 'thơm nha', 2, 5, 8, '2025-11-20 02:10:54'),
	(18, 'Mua có được tặng kèm quà không shop', 17, 3, 11, '2025-12-08 16:39:21');

-- Dumping structure for table shoppingdb.coupons
CREATE TABLE IF NOT EXISTS `coupons` (
  `coupon_type` varchar(31) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `discount_value` decimal(38,2) DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `is_percentage` bit(1) NOT NULL,
  `max_discount_amount` decimal(38,2) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `min_order_amount` decimal(38,2) DEFAULT NULL,
  `target_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKeplt0kkm9yf2of2lnx6c1oy9b` (`code`),
  KEY `FKngikc5nyjutnt8jfnedpv8jsv` (`target_category_id`),
  CONSTRAINT `FKngikc5nyjutnt8jfnedpv8jsv` FOREIGN KEY (`target_category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.coupons: ~3 rows (approximately)
REPLACE INTO `coupons` (`coupon_type`, `id`, `active`, `code`, `description`, `discount_value`, `end_date`, `image_url`, `is_percentage`, `max_discount_amount`, `quantity`, `start_date`, `min_order_amount`, `target_category_id`) VALUES
	('CATEGORY_SPECIFIC', 2, b'1', 'CHANEL11', 'DEAL SỐC THÁNG 11', 15.00, '2025-12-27', NULL, b'1', 1000000.00, 0, '2025-11-27', NULL, 1),
	('WELCOME', 3, b'1', 'NEWCUS12', 'GIẢM GIÁ 15% CHO ĐƠN HÀNG ĐẦU TIÊN', 15.00, '2025-12-11', NULL, b'1', NULL, 1, '2025-12-02', NULL, NULL),
	('WELCOME', 4, b'1', 'NOEL12', 'LẦN ĐẦU MUA SẮM THÁNG 12 NÀY', 50.00, '2025-12-11', NULL, b'1', NULL, 1, '2025-12-02', NULL, NULL),
	('CATEGORY_SPECIFIC', 5, b'0', '70549', 'TEST THỬ NÀO', 1000000.00, NULL, NULL, b'0', NULL, 1, NULL, NULL, 3);

-- Dumping structure for table shoppingdb.customers
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_since` date NOT NULL,
  `name` varchar(100) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `gender` enum('NAM','NU','UNISEX') DEFAULT NULL,
  `id_card` varchar(255) DEFAULT NULL,
  `nick_name` varchar(50) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `ward` varchar(100) DEFAULT NULL,
  `street_detail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_customer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.customers: ~4 rows (approximately)
REPLACE INTO `customers` (`id`, `customer_since`, `name`, `user_id`, `birthday`, `email`, `gender`, `id_card`, `nick_name`, `phone_number`, `province`, `district`, `ward`, `street_detail`) VALUES
	(8, '2025-10-19', 'Trần Phương Nhi', 11, '2025-11-20', '', 'NU', '', 'LÙN nè', '0765593697', NULL, NULL, NULL, NULL),
	(9, '2025-11-15', 'admin', 12, '0000-00-00', '', NULL, '', '', '', NULL, NULL, NULL, NULL),
	(10, '2025-11-21', 'Nguyễn Minh Toàn', 14, '2025-11-26', 'mtoan0547@gmail.com', 'NAM', NULL, 'OKE', '0765593697', 'Thành phố Hồ Chí Minh', 'Quận 8', 'Phường 7', '2345/13 Pham The Hien'),
	(11, '2025-12-08', 'Nguyễn Danh Hữu Minh', 15, NULL, 'toannguyen041214@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- Dumping structure for table shoppingdb.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime(6) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `delivery_date` datetime(6) DEFAULT NULL,
  `discount_amount` decimal(38,2) DEFAULT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `payment_method` enum('COD','MOMO','PAYPAL','VNPAY','ZALOPAY') NOT NULL,
  `payment_status` bit(1) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `shipping_address` varchar(500) NOT NULL,
  `status` enum('CANCELLED','COMPLETED','DELIVERED','PENDING','SHIPPING') NOT NULL,
  `shipping_fee` decimal(38,2) DEFAULT NULL,
  `shipping_method` enum('EXPRESS','STANDARD') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpxtb8awmi0dk6smoh2vp1litg` (`customer_id`),
  CONSTRAINT `FKpxtb8awmi0dk6smoh2vp1litg` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.orders: ~2 rows (approximately)
REPLACE INTO `orders` (`id`, `date`, `customer_id`, `delivery_date`, `discount_amount`, `note`, `payment_method`, `payment_status`, `phone_number`, `shipping_address`, `status`, `shipping_fee`, `shipping_method`) VALUES
	(83, '2025-12-02 01:28:16.153352', 10, '2025-12-07 19:55:04.412977', 127500.00, '', 'COD', b'0', '0765593697', '2345/13 Pham The Hien, Phường 7, Quận 8, Thành phố Hồ Chí Minh', 'DELIVERED', 15000.00, 'STANDARD'),
	(84, '2025-12-07 20:02:20.747217', 10, '2025-12-10 20:02:20.747217', 0.00, 'Nhà cửa màu đỏ', 'PAYPAL', b'0', '0765593697', '2345/13 Pham The Hien, Phường 7, Quận 8, Thành phố Hồ Chí Minh', 'SHIPPING', 15000.00, 'STANDARD');

-- Dumping structure for table shoppingdb.order_lines
CREATE TABLE IF NOT EXISTS `order_lines` (
  `amount` int(11) NOT NULL,
  `purchase_price` decimal(38,2) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`,`product_id`),
  KEY `FK5v1oeejtgtf2n3toppm3tkuhh` (`product_id`),
  CONSTRAINT `FK1smc0s578t2oih21yn9hw6usr` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `FK5v1oeejtgtf2n3toppm3tkuhh` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.order_lines: ~0 rows (approximately)
REPLACE INTO `order_lines` (`amount`, `purchase_price`, `order_id`, `product_id`) VALUES
	(1, 850000.00, 83, 13),
	(1, 850000.00, 84, 13);

-- Dumping structure for table shoppingdb.products
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `category_id` int(11) NOT NULL,
  `image_url` varchar(512) DEFAULT NULL,
  `hot_trend` tinyint(1) DEFAULT 0,
  `volume` varchar(50) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `average_rating` double DEFAULT 0,
  `rating_count` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKog2rp4qthbtt2lfyhfo32lsw9` (`category_id`),
  CONSTRAINT `FKog2rp4qthbtt2lfyhfo32lsw9` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.products: ~14 rows (approximately)
REPLACE INTO `products` (`id`, `name`, `price`, `quantity`, `category_id`, `image_url`, `hot_trend`, `volume`, `gender`, `average_rating`, `rating_count`, `description`) VALUES
	(1, 'Chanel N5 Eau de Parfum', 3500000, 35, 1, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122441/shopnuochoa_products/ryztubrkv6vqp1hpgtky.jpg', 1, 'ML_100', 'NU', 0, NULL, 'Biểu tượng của sự nữ tính và sang trọng tuyệt đối. Sự pha trộn hoàn hảo của hoa hồng tháng Năm, hoa nhài và hương Aldehydes đặc trưng.'),
	(2, 'Bleu de Chanel Eau de Toilette', 2800000, 63, 1, 'https://www.ecosmetics.com/wp-content/uploads/2022/10/3145891073508-600x600.jpg', 0, 'ML_100', 'NAM', 5, 1, 'Mùi hương gỗ thơm nồng nàn dành cho người đàn ông hiện đại. Sự kết hợp giữa cam Bergamot, bạc hà và gỗ đàn hương tạo nên dấu ấn nam tính.'),
	(3, 'Sauvage Eau de Parfum', 3100000, 80, 2, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122382/shopnuochoa_products/orna8q1rnrng5berzsu3.jpg', 1, 'ML_100', 'NAM', 0, NULL, 'Lấy cảm hứng từ những không gian mở. Hương cam Bergamot tươi mát quyện cùng tiêu đen và Ambroxan tạo nên sự mạnh mẽ, hoang dã.'),
	(4, 'J\'adore Eau de Parfum', 3800000, 45, 2, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122351/shopnuochoa_products/fm62ngm7puijtf3eqnnx.jpg', 0, 'ML_100', 'NU', 0, NULL, 'Tôn vinh vẻ đẹp nữ tính. Bó hoa rực rỡ với hoa lan Tây, hoa hồng Damascena và hoa nhài Sambac. Một mùi hương gợi cảm, tinh tế.'),
	(5, 'Gucci Bloom Eau de Parfum', 2950000, 60, 3, 'https://storage.beautyfulls.com/uploads-1/avatar/product/1200x/2022/10/05/figure-1664937209959.png', 0, 'ML_100', 'NU', 0, NULL, 'Khu vườn đầy hoa nở rộ. Hương thơm đậm đà của hoa huệ trắng, hoa nhài và hoa sử quân tử. Mang lại cảm giác chân thực.'),
	(7, 'Creed Aventus', 8200000, 25, 5, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122294/shopnuochoa_products/jnajh0gxfeb5ol2mg7em.jpg', 1, 'ML_100', 'NAM', 0, NULL, 'Ông vua của nước hoa nam. Hương dứa nướng khói đặc trưng kết hợp với gỗ bạch dương. Biểu tượng của sức mạnh và thành công.'),
	(8, 'Versace Eros Eau de Toilette', 2100000, 100, 1, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122261/shopnuochoa_products/qtrv2xtbj7vtf62itq0e.jpg', 0, 'ML_100', 'NAM', 0, NULL, 'Thần tình yêu đầy đam mê. Sự bùng nổ của bạc hà, táo xanh và đậu Tonka. Ngọt ngào, quyến rũ và đầy nam tính.'),
	(9, 'YSL Black Opium', 3300000, 55, 1, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122215/shopnuochoa_products/gdrw5ti1zomhljydxslz.jpg', 0, 'ML_75', 'NU', 0, NULL, 'Gây nghiện và táo bạo. Sự tương phản giữa cà phê đen năng lượng và vani ngọt ngào. Dành cho cô nàng cá tính, bí ẩn.'),
	(10, 'Acqua di Giò Profondo', 2900000, 65, 1, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122171/shopnuochoa_products/li3qemv2prhphecwtzfq.png', 0, 'ML_200', 'NAM', 0, NULL, 'Khám phá đại dương sâu thẳm. Hương biển mặn mà kết hợp với cam Bergamot và hương thảo. Mát lạnh, sảng khoái.'),
	(11, 'Jo Malone English Pear & Freesia', 3600000, 40, 1, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122498/shopnuochoa_products/voulvekcwjuemlepxsqa.jpg', 0, 'ML_100', 'UNISEX', 0, NULL, 'Tinh tế như mùa thu nước Anh. Hương lê chín mọng bao bọc bởi hoa lan nam phi trắng. Nhẹ nhàng, thanh lịch.'),
	(12, 'Le Labo Santal 33', 7500000, 16, 1, 'https://orchard.vn/wp-content/uploads/2024/07/le-labo-santal-33_2.jpg', 0, 'ML_100', 'UNISEX', 0, NULL, 'Hương gỗ đàn hương, tuyết tùng và da thuộc. Độc đáo, cá tính và lưu hương cực lâu. Mùi hương Unisex kinh điển.'),
	(13, 'Morra - Gỗ Đàn Hương (Sandalwood)', 850000, 25, 1, 'https://salt.tikicdn.com/ts/tmp/70/92/69/c72a1e98a98f936db20decc31877175d.png', 0, 'ML_50', 'UNISEX', 0, NULL, 'Hương thơm ấm áp và trầm mặc của gỗ đàn hương. Mang lại cảm giác thư thái, bình yên. Phù hợp cho những ngày se lạnh.'),
	(14, 'ViinRiic - Mưa Sài Gòn (Saigon Rain)', 2500000, 32, 12, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122109/shopnuochoa_products/g4y1xizfxfcqzxs0owz2.jpg', 0, 'ML_50', 'UNISEX', 0, 0, 'Gợi nhớ về những cơn mưa Sài Gòn. Hương thơm của đất ẩm, lá cây và sự tươi mát. Một mùi hương đầy hoài niệm.'),
	(17, 'CHANCE EAU SPLENDIDE', 10000000, 99, 1, 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1765122047/shopnuochoa_products/mk07xfidft5j84y9vhpm.jpg', 0, 'ML_150', 'NU', 3, 1, 'Phiên bản rạng rỡ và tươi vui. Hương hoa cỏ trái cây đầy năng lượng, mang lại sự trẻ trung và lạc quan.');

-- Dumping structure for table shoppingdb.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('ADMIN','CUSTOMER','GUEST') NOT NULL DEFAULT 'CUSTOMER',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `full_name` varchar(100) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.users: ~4 rows (approximately)
REPLACE INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `is_active`, `created_at`, `full_name`, `avatar`) VALUES
	(11, 'nhi', 'nhiPhuong@gmail.com', '$2a$10$bzGBNkIT5CLGiL6iGpkVEeDJIrY4t7aBSkKHGWJyRGz6bOAMzRMhC', 'CUSTOMER', 1, '2025-10-19 05:42:48', 'Trần Phương Nhi', 'http://res.cloudinary.com/dlvtnwywp/image/upload/v1763903557/shopnuochoa_avatars/nkzjb13zoxqrbye6cvok.jpg'),
	(12, 'admin', 'admin@gmail.com', '$2a$10$jtS6OIDroUy/3vJgzMZJlOFIGt3XhrbN7hYG9r3diPwDezULNbQke', 'ADMIN', 1, '2025-11-14 19:46:52', 'admin', NULL),
	(14, 'toan', 'mtoan0547@gmail.com', '$2a$10$tTHZT0upAdPg016P.JRLQOxiK7YBt8kqW6bRJimhhzz87tC9DyIMu', 'CUSTOMER', 1, '2025-11-21 16:55:16', 'Nguyễn Minh Toàn', NULL),
	(15, 'minh01', 'toannguyen041214@gmail.com', '$2a$10$OkuT/OBE7kBUSDhufSOJGeCKlexOK7LVwl5AnSoQkMGYz.S0DHlqm', 'CUSTOMER', 1, '2025-12-08 07:58:18', 'Nguyễn Danh Hữu Minh', NULL);

-- Dumping structure for table shoppingdb.wishlist
CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6p7qhvy1bfkri13u29x6pu8au` (`product_id`),
  KEY `FKk6lal9w7ut5e4xvta479rq06y` (`customer_id`),
  CONSTRAINT `FK6p7qhvy1bfkri13u29x6pu8au` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `FKk6lal9w7ut5e4xvta479rq06y` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.wishlist: ~0 rows (approximately)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
