-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.8.4-MariaDB - MariaDB Server
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for shoppingdb
CREATE DATABASE IF NOT EXISTS `shoppingdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;
USE `shoppingdb`;

-- Dumping structure for table shoppingdb.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `country` varchar(100) DEFAULT NULL,
  `imgURL` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKt8o6pivur7nn124jehx7cygw5` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.categories: ~5 rows (approximately)
REPLACE INTO `categories` (`id`, `name`, `country`, `imgURL`) VALUES
	(1, 'Điện tử mới', 'Quốc tế', 'https://example.com/images/electronics.png'),
	(2, 'Thời trang', 'Pháp', 'https://example.com/images/fashion.png'),
	(3, 'Sách', 'Việt Nam', 'https://example.com/images/books.png'),
	(4, 'Đồ gia dụng', 'Hàn Quốc', 'https://example.com/images/appliances.png'),
	(5, 'Thực phẩm', 'Việt Nam', 'https://example.com/images/food.png');

-- Dumping structure for table shoppingdb.comments
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6uv0qku8gsu6x1r2jkrtqwjtn` (`product_id`),
  KEY `fk_comment_customer` (`customer_id`),
  CONSTRAINT `FK6uv0qku8gsu6x1r2jkrtqwjtn` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_comment_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.comments: ~3 rows (approximately)
REPLACE INTO `comments` (`id`, `text`, `product_id`, `rating`, `customer_id`, `created_at`) VALUES
	(14, 'hay qua ta 1', 14, 4, 8, '2025-11-15 18:38:46'),
	(15, 'muon 1 loc nha', 14, 5, 8, '2025-11-15 18:38:46'),
	(16, '+1 san pham', 14, 3, 8, '2025-11-15 18:43:20');

-- Dumping structure for table shoppingdb.customers
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_since` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_customer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.customers: ~8 rows (approximately)
REPLACE INTO `customers` (`id`, `customer_since`, `name`, `user_id`) VALUES
	(1, '2024-01-20', 'Nguyễn Văn An', 1),
	(3, '2024-05-22', 'Lê Hoàng Cường', 3),
	(4, '2024-07-30', 'Phạm Thị Diệu', 4),
	(5, '2024-09-05', 'Võ Minh Em', 5),
	(6, '2025-10-12', 'Nguyễn Danh Minh Toàn', 6),
	(7, '2025-10-15', 'Chu cha mà ơi', 10),
	(8, '2025-10-19', 'Trần Phương Nhi', 11),
	(9, '2025-11-15', 'admin', 12);

-- Dumping structure for table shoppingdb.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime(6) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpxtb8awmi0dk6smoh2vp1litg` (`customer_id`),
  CONSTRAINT `FKpxtb8awmi0dk6smoh2vp1litg` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.orders: ~23 rows (approximately)
REPLACE INTO `orders` (`id`, `date`, `customer_id`) VALUES
	(1, '2025-08-10 10:30:00.000000', 1),
	(3, '2025-09-01 09:15:00.000000', 1),
	(4, '2025-09-20 18:00:00.000000', 3),
	(5, '2025-10-05 11:45:00.000000', 4),
	(12, '2025-10-13 14:34:20.940197', 1),
	(13, '2025-10-14 14:25:22.519747', 1),
	(14, '2025-10-15 15:40:26.321962', 7),
	(15, '2025-10-17 15:02:11.315567', 7),
	(16, '2025-10-17 15:05:36.181008', 7),
	(17, '2025-10-17 15:06:19.843543', 7),
	(18, '2025-10-17 15:16:38.223658', 7),
	(19, '2025-10-18 12:01:37.584176', 7),
	(20, '2025-10-19 21:34:37.844631', 8),
	(21, '2025-11-07 02:17:45.831798', 8),
	(22, '2025-11-08 14:29:44.219297', 8),
	(23, '2025-11-11 00:16:13.232524', 8),
	(24, '2025-11-16 00:44:13.090901', 8),
	(25, '2025-11-16 00:52:28.993997', 8),
	(26, '2025-11-16 13:57:03.593952', 8),
	(27, '2025-11-17 01:39:50.291874', 8),
	(28, '2025-11-17 01:59:21.498729', 8),
	(29, '2025-11-17 02:10:00.103657', 8),
	(30, '2025-11-17 02:13:40.154595', 8);

-- Dumping structure for table shoppingdb.order_lines
CREATE TABLE IF NOT EXISTS `order_lines` (
  `amount` int(11) NOT NULL,
  `purchase_price` decimal(38,2) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`,`product_id`),
  KEY `FK5v1oeejtgtf2n3toppm3tkuhh` (`product_id`),
  CONSTRAINT `FK1smc0s578t2oih21yn9hw6usr` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `FK5v1oeejtgtf2n3toppm3tkuhh` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.order_lines: ~26 rows (approximately)
REPLACE INTO `order_lines` (`amount`, `purchase_price`, `order_id`, `product_id`) VALUES
	(1, 32500000.00, 1, 1),
	(1, 150000.00, 3, 3),
	(3, 55000.00, 3, 5),
	(1, 550000.00, 4, 2),
	(10, 55000.00, 5, 5),
	(1, 32500000.00, 12, 1),
	(1, 550000.00, 13, 2),
	(1, 150000.00, 13, 3),
	(1, 32500000.00, 14, 1),
	(1, 32500000.00, 15, 1),
	(1, 32500000.00, 16, 1),
	(1, 150000.00, 17, 3),
	(1, 32500000.00, 18, 1),
	(2, 550000.00, 18, 2),
	(1, 32500000.00, 19, 1),
	(1, 32500000.00, 20, 1),
	(1, 100000.00, 21, 14),
	(3, 100000.00, 22, 14),
	(1, 32500000.00, 23, 1),
	(1, 100000.00, 24, 14),
	(2, 100000.00, 25, 14),
	(1, 100000.00, 26, 14),
	(1, 100000.00, 27, 14),
	(1, 100000.00, 28, 14),
	(1, 100000.00, 29, 14),
	(1, 100000.00, 30, 14);

-- Dumping structure for table shoppingdb.products
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `category_id` int(11) NOT NULL,
  `image_url` varchar(512) DEFAULT NULL,
  `hot_trend` tinyint(1) DEFAULT 0,
  `volume` varchar(50) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `average_rating` double DEFAULT 0,
  `rating_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKog2rp4qthbtt2lfyhfo32lsw9` (`category_id`),
  CONSTRAINT `FKog2rp4qthbtt2lfyhfo32lsw9` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.products: ~13 rows (approximately)
REPLACE INTO `products` (`id`, `name`, `price`, `quantity`, `category_id`, `image_url`, `hot_trend`, `volume`, `gender`, `average_rating`, `rating_count`) VALUES
	(1, 'iPhone 15 Pro Max 256GB', 32500000, 11, 1, 'https://minhtuanmobile.com/uploads/products/231209053742-iphone-15-256gb.jpg', 1, 'ML_100', 'UNISEX', 0, NULL),
	(2, 'Váy Hoa Nhí Vintage Cổ Vuông', 550000, 11, 2, 'https://example.com/images/vay-hoa-nhi.jpg', 0, 'ML_50', 'NU', 0, NULL),
	(3, 'Sách "Muôn Kiếp Nhân Sinh"', 150000, 5, 3, 'https://example.com/images/sach-muon-kiep.jpg', 1, 'ML_100', 'UNISEX', 0, NULL),
	(4, 'Bộ Lau Nhà Tự Vắt Thông Minh', 250000, 6, 4, 'https://example.com/images/bo-lau-nha.jpg', 0, 'ML_200', 'UNISEX', 0, NULL),
	(5, 'Cà Phê Hòa Tan G7 3in1', 55000, 7, 5, 'https://example.com/images/ca-phe.jpg', 0, 'ML_30', 'UNISEX', 0, NULL),
	(7, 'Laptop Acer icore5', 37000000, 8, 1, 'https://example.com/images/laptop-acer.jpg', 1, 'ML_150', 'NAM', 0, NULL),
	(8, 'Chuột máy tính', 1000000, 11, 1, 'https://example.com/images/chuot-may-tinh.jpg', 0, 'ML_75', 'UNISEX', 0, NULL),
	(9, 'Bàn phím thu gọn', 2000000, 12, 1, 'https://example.com/images/ban-phim.jpg', 0, 'ML_150', 'UNISEX', 0, NULL),
	(10, 'Tai nghe có dây', 50000, 14, 1, 'https://example.com/images/tai-nghe.jpg', 0, 'ML_50', 'UNISEX', 0, NULL),
	(11, 'Cục sạc dự phòng', 500000, 16, 1, 'https://example.com/images/cuc-sac.jpg', 0, 'ML_10', 'UNISEX', 0, NULL),
	(12, 'Điện thoại iphone 17 pro', 37000000, 18, 1, 'https://example.com/images/iphone-17-pro.jpg', 0, 'ML_100', 'UNISEX', 0, NULL),
	(13, 'Ipad Xaomi', 10000000, 17, 1, 'https://example.com/images/ipad-xiaomi.jpg', 0, 'ML_200', 'UNISEX', 0, NULL),
	(14, 'Áo Mưa', 100000, 6, 2, 'https://example.com/images/ao-mua.jpg', 0, 'ML_75', 'NU', 4, 3);

-- Dumping structure for table shoppingdb.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('ADMIN','CUSTOMER','GUEST') NOT NULL DEFAULT 'CUSTOMER',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `full_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.users: ~10 rows (approximately)
REPLACE INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `is_active`, `created_at`, `full_name`) VALUES
	(1, 'an_nguyen', 'an.nguyen@example.com', '$2a$10$BhmsPnot4Q6B.58XS6XuYeeIMqsYgnfs8YzBaS7dum67RV/ZbV/Dy', 'CUSTOMER', 1, '2025-10-14 06:46:54', 'Nguyễn Văn An'),
	(3, 'cuong_le', 'cuong.le@example.com', '$2a$10$aB.cDeFgHijklMnoPqRsTuVwXyZaBcDeFgHijklMnoPq', 'CUSTOMER', 1, '2025-10-14 06:46:54', 'Lê Hoàng Cường'),
	(4, 'dieu_pham', 'dieu.pham@example.com', '$2a$10$9rStUvWxYzAbCdEfGhIjKu8lMnOpQrStUvWxYzAbCdEfGh', 'CUSTOMER', 1, '2025-10-14 06:46:54', 'Phạm Thị Diệu'),
	(5, 'em_vo', 'em.vo@example.com', '$2a$10$kL.mNoPqRsTuVwXyZaBcDeFgHijklMnoPqRsTuVwXyZ', 'CUSTOMER', 1, '2025-10-14 06:46:54', 'Võ Minh Em'),
	(6, 'toan_nguyen', 'toan.nguyen@example.com', '$2a$10$oPqRsTuVwXyZaBcDeFgHijklMnoPqRsTuVwXyZaBcDeF', 'ADMIN', 1, '2025-10-14 06:46:54', 'Nguyễn Danh Minh Toàn'),
	(8, 'test', 'toan@gmail.com', '$2a$10$yUQ2Lr8/R7zHvAwXrqYwG.Xa0vagtPdGfVAqwsq3.5vGOvhWHwxbe', 'CUSTOMER', 1, '2025-10-15 05:57:42', 'Nguyen danh minh'),
	(9, 'noat04', 'toannguyen041214@gmail.com', '$2a$10$j4eVa.jsqwngqkzIzH674uYc5f65rmEYoerw5mS6ZKVATXrWkHbvS', 'CUSTOMER', 1, '2025-10-15 06:29:43', 'Nguyễn Danh Minh Toàn'),
	(10, 'chu', 'chu@gmail.com', '$2a$10$y225smkQ834mzGJPgIiV4OfoNhWTohN9w96upZ0FY.mjAww//V/tG', 'ADMIN', 1, '2025-10-15 08:13:16', 'Chu cha mà ơi'),
	(11, 'nhi', 'nhiPhuong@gmail.com', '$2a$10$bzGBNkIT5CLGiL6iGpkVEeDJIrY4t7aBSkKHGWJyRGz6bOAMzRMhC', 'CUSTOMER', 1, '2025-10-19 05:42:48', 'Trần Phương Nhi'),
	(12, 'admin', 'admin@gmail.com', '$2a$10$jtS6OIDroUy/3vJgzMZJlOFIGt3XhrbN7hYG9r3diPwDezULNbQke', 'ADMIN', 1, '2025-11-14 19:46:52', 'admin');

-- Dumping structure for table shoppingdb.vector_store
CREATE TABLE IF NOT EXISTS `vector_store` (
  `id` uuid NOT NULL,
  `content` tinytext NOT NULL,
  `metadata` tinytext DEFAULT NULL,
  `embedding` blob DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table shoppingdb.vector_store: ~0 rows (approximately)

-- Dumping structure for table shoppingdb.wishlist
CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6p7qhvy1bfkri13u29x6pu8au` (`product_id`),
  KEY `FKk6lal9w7ut5e4xvta479rq06y` (`customer_id`),
  CONSTRAINT `FK6p7qhvy1bfkri13u29x6pu8au` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `FKk6lal9w7ut5e4xvta479rq06y` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Dumping data for table shoppingdb.wishlist: ~0 rows (approximately)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
